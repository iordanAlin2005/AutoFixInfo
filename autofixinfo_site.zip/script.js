window.onload = () => {
  setTimeout(() => {
    document.getElementById("loading").style.display = "none";
    document.getElementById("content").style.display = "block";
  }, 1000);
};

function searchCar() {
  const input = document.getElementById("search").value.toLowerCase();
  const items = document.querySelectorAll("#car-list li");
  items.forEach((item) => {
    if (item.textContent.toLowerCase().includes(input)) {
      item.style.display = "block";
    } else {
      item.style.display = "none";
    }
  });
}

function showInfo(model) {
  const infoBox = document.getElementById("car-info");
  let info = '';
  if (model === "Volkswagen Golf 5") {
    info = "<h2>Golf 5 - Probleme comune:</h2><ul><li>Blocare geamuri electrice</li><li>Probleme la EGR</li></ul>";
  } else if (model === "Dacia Logan") {
    info = "<h2>Logan - Probleme comune:</h2><ul><li>Uzură la suspensii</li><li>Probleme la injectoare</li></ul>";
  } else {
    info = "<p>Modelul nu este încă în baza de date.</p>";
  }
  infoBox.innerHTML = info;
}